### Signaturen für den GC little helper II (cut & paste):<br>
<br>

<img src="../images/signature01.jpg" alt="signature01.jpg"><br>
* `[b]GC little helper II[/b]: [url=http://geoclub.de/forum/viewforum.php?f=117]Help[/url] | [url=https://raw.githubusercontent.com/2Abendsegler/GClh/master/gc_little_helper_II.user.js]Install script[/url] | [url=https://goo.gl/DWmgCM]Changelog[/url] | [url=https://goo.gl/xb0vzI]Open issues[/url] | [url=https://github.com/2Abendsegler/GClh/tree/master#readme]Info[/url]`
<br><br>

<img src="../images/signature02.jpg" alt="signature02.jpg"><br>
* `[b]GC little helper II[/b] - [i]continues...[/i]`
* `[url=http://geoclub.de/forum/viewforum.php?f=117]Help[/url] | [url=https://raw.githubusercontent.com/2Abendsegler/GClh/master/gc_little_helper_II.user.js]Install script[/url] | [url=https://goo.gl/DWmgCM]Changelog[/url] | [url=https://goo.gl/xb0vzI]Open issues[/url] | [url=https://github.com/2Abendsegler/GClh/tree/master]GitHub[/url]`
<br><br>

<img src="../images/signature03.jpg" alt="signature03.jpg"><br>
* `[b]GC little helper II[/b]: [url=http://geoclub.de/forum/viewforum.php?f=117]Help[/url] | [url=https://raw.githubusercontent.com/2Abendsegler/GClh/master/gc_little_helper_II.user.js]Install script[/url] | [url=https://goo.gl/DWmgCM]Changelog[/url] | [url=https://goo.gl/xb0vzI]Open issues[/url] | [url=https://goo.gl/YdEt8L]Open wishes[/url]`
<br><br>

<img src="../images/signature04.jpg" alt="signature04.jpg"><br>
* `[b]GC little helper II[/b] - [i]continues...[/i]`
* `[url=http://geoclub.de/forum/viewforum.php?f=117]Help[/url] | [url=https://raw.githubusercontent.com/2Abendsegler/GClh/master/gc_little_helper_II.user.js]Install script[/url] | [url=https://goo.gl/DWmgCM]Changelog[/url] | [url=https://goo.gl/xb0vzI]Open issues[/url] | [url=https://goo.gl/YdEt8L]Open wishes[/url]`
